import { initApi } from './api'

export { initApi }
