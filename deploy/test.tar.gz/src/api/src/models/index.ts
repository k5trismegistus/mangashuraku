import { IBook, IBookParameter } from './book'

export { IBook, IBookParameter }
