import getBookPageComponent from './getBookPageComponent'

export {
  getBookPageComponent
}
